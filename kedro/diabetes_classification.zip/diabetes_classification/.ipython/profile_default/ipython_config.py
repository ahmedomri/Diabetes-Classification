c.InteractiveShellApp.extensions.append("kedro.extras.extensions.ipython")
