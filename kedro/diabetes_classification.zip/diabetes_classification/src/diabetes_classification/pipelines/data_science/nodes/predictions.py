def predictions(knn, X_test):
    y_pred = knn.predict(X_test)
    return y_pred
