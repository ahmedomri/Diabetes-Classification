"""Diabetes_Classification
"""

__version__ = "0.1"
